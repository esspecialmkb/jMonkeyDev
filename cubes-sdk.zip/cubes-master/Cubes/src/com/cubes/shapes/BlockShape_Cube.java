/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cubes.shapes;

/**
 *
 * @author Carl
 */
public class BlockShape_Cube extends BlockShape_Cuboid{

    public BlockShape_Cube(){
        super(new float[]{0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f});
    }
}
